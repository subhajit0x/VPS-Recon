|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |  1552 | dhiyaneshdk   |   701 | cves             |  1529 | info     |  1671 | http    |  4330 |
| panel     |   780 | daffainfo     |   662 | exposed-panels   |   782 | high     |  1152 | file    |    78 |
| edb       |   582 | pikpikcu      |   344 | vulnerabilities  |   520 | medium   |   837 | network |    77 |
| exposure  |   551 | pdteam        |   274 | misconfiguration |   361 | critical |   552 | dns     |    17 |
| xss       |   543 | geeknik       |   206 | technologies     |   322 | low      |   281 |         |       |
| lfi       |   519 | pussycat0x    |   172 | exposures        |   308 | unknown  |    25 |         |       |
| wordpress |   471 | dwisiswant0   |   171 | token-spray      |   236 |          |       |         |       |
| cve2021   |   370 | 0x_akoko      |   170 | workflows        |   190 |          |       |         |       |
| wp-plugin |   366 | ritikchaddha  |   164 | default-logins   |   116 |          |       |         |       |
| tech      |   360 | princechaddha |   153 | file             |    78 |          |       |         |       |
